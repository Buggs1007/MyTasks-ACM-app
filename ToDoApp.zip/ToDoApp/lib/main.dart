import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:todo_app_ui_ii_example/page/home_page.dart';
import 'package:todo_app_ui_ii_example/provider/todos.dart';

Future main() async {

  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    // Replace with actual values
      options: FirebaseOptions(
        apiKey: "AIzaSyCLZe1Y0IgjiUO1j1ctetc0O4i_PLsukGM",
        appId: "1:703892969678:android:6a698be4fba999a471189f",
        messagingSenderId: "703892969678",
        projectId: "mytodotasks-36ed9",
      ),
  );

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  static final String title = 'MyTasks';

  @override
  Widget build(BuildContext context) => ChangeNotifierProvider(
    create: (context) => TodosProvider(),
    child: MaterialApp(
      debugShowCheckedModeBanner: false,
      title: title,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Color(0xFFf6f5ee),
      ),
      home: HomePage(),
    ),
  );
}