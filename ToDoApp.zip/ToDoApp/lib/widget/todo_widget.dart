import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:provider/provider.dart';
import 'package:todo_app_ui_ii_example/model/todo.dart';
import 'package:todo_app_ui_ii_example/page/edit_todo_page.dart';
import 'package:todo_app_ui_ii_example/provider/todos.dart';
import 'package:todo_app_ui_ii_example/utils.dart';

class TodoWidget extends StatelessWidget {
  final Todo todo;

  const TodoWidget({
    @required this.todo,
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) =>
      ClipRRect(
        borderRadius: BorderRadius.circular(25),
        child: Slidable(
          actionPane: SlidableDrawerActionPane(),
          key: Key(todo.id),
          actions: [
            IconSlideAction(
              color: Colors.blue[900],
              // onTap: () => editTodo(context, todo),
              caption: 'Edit',
              icon: Icons.edit,
            )
          ],
          secondaryActions: [
            IconSlideAction(
              color: Colors.black,
              caption: 'Delete',
              //onTap: () => deleteTodo(context, todo),
              icon: Icons.delete,
            )
          ],
          child: buildTodo(context),
        ),
      );

 /* Widget buildTodo(BuildContext context) {
    var todos = Provider.of<TodosProvider>(context, listen: false);
    return Scaffold(
      body: FutureBuilder(
          future: todos.GetData(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              // here consume your Todos
              List<Todo> todos = snapshot.data as List<Todo>;
              child:
              Container(
                color: Colors.white,
                padding: EdgeInsets.all(20),
                child: Row(
                  children: [
                Checkbox(
                activeColor: Colors.green[500],
                  checkColor: Colors.white,
                  value: todo.isDone,
                  onChanged: (_) {
                    final provider = Provider.of<TodosProvider>(
                        context, listen: false),
                        todo = provider.GetData();
                    final isDone = provider.toggleTodoStatus(this.todo);
                    Utils.showSnackBar(
                      context,
                      isDone ? 'Task completed' : 'Task marked incomplete',
                    );
                  },
                ),
                const SizedBox(width: 20),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        this.todo.title,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Theme
                              .of(context)
                              .primaryColor,
                          fontSize: 22,
                        ),
                      ),
                      if (this.todo.description.isNotEmpty)
                        Container(
                          margin: EdgeInsets.only(top: 4),
                          child: Text(
                            todo.description,
                            style: TextStyle(fontSize: 20, height: 1.5),
                          ),
                        ),
                    ],
                  ),
                ),
                ],
              ),
            );
          }
            return CircularProgressIndicator();
          }
      ),
    );*/
Widget buildTodo(BuildContext context) => GestureDetector(
  onTap: () => editTodo(context, todo),
  child: Container(
      color: Colors.white,
      padding: EdgeInsets.all(20),
      child: Row(
        children: [
          Checkbox(
            activeColor: Colors.green[500],
            checkColor: Colors.white,
            value: todo.isDone,
            onChanged: (_) {
              final provider = Provider.of<TodosProvider>(context, listen: false);
              final isDone = provider.toggleTodoStatus(todo);
              Utils.showSnackBar(
                context,
                isDone ? 'Task completed' : 'Task marked incomplete',
              );
            },
          ),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  todo.title,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).primaryColor,
                    fontSize: 22,
                  ),
                ),
                if (todo.description.isNotEmpty)
                  Container(
                    margin: EdgeInsets.only(top: 4),
                    child: Text(
                      todo.description,
                      style: TextStyle(fontSize: 20, height: 1.5),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    ),
  );




    void deleteTodo(BuildContext context, Todo todo) {
      final provider = Provider.of<TodosProvider>(context, listen: false);
      provider.removeTodo(todo);

      Utils.showSnackBar(context, 'Deleted the task');
    }

    void editTodo(BuildContext context, Todo todo) =>
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => EditTodoPage(todo: todo),
          ),
        );
  }
