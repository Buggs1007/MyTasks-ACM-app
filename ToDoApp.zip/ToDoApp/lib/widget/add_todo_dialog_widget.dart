import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:todo_app_ui_ii_example/model/todo.dart';
import 'package:todo_app_ui_ii_example/provider/todos.dart';
import 'package:todo_app_ui_ii_example/widget/todo_form_widget.dart';
import 'package:todo_app_ui_ii_example/utils.dart';

class AddTodoDialogWidget extends StatefulWidget {
  @override
  _AddTodoDialogWidgetState createState() => _AddTodoDialogWidgetState();
}
class _AddTodoDialogWidgetState extends State<AddTodoDialogWidget> {
  final _formKey = GlobalKey<FormState>();

  String title = '';
  String description = '';
 @override
  Widget build(BuildContext context)   => AlertDialog(

    content: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Add a Task',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 22,
                ),
              ),
              const SizedBox(height: 8),
              TodoFormWidget(
                onChangedTitle: (title) => setState(() => this.title = title),
                onChangedDescription: (description) =>setState(() => this.description = description),
                onSavedTodo: addTodo,
              ),
            ],
          ),
        ),
      );

  void addTodo() async {
    final isValid = _formKey.currentState.validate();
    if (!isValid) {
      //Utils.showSnackBar(context,'Kindly provide values');
      return;
    } else {
      final todo = Todo(
        id: DateTime.now().toString(),
        title: title,
        description: description,
        createdTime: DateTime.now(),
      );
      final provider = Provider.of<TodosProvider>(context, listen: false);
      provider.addTodo(todo);
      WidgetsFlutterBinding.ensureInitialized();
      await Firebase.initializeApp(
        // Replace with actual values
        options: FirebaseOptions(
          apiKey: "AIzaSyCLZe1Y0IgjiUO1j1ctetc0O4i_PLsukGM",
          appId: "1:703892969678:android:6a698be4fba999a471189f",
          messagingSenderId: "703892969678",
          projectId: "mytodotasks-36ed9",
        ),
      );
      DocumentReference documentReference = FirebaseFirestore.instance.collection("MyTodos").doc(title);

      Map<String, String> todoList = {
        "id": DateTime.now().toString(),
        "createdTime": DateTime.now().toString(),
        "title": title,
        "description": description,
        "isDone": "false",
      };

      documentReference
          .set(todoList)
          .whenComplete(() => print("Data stored successfully"));

      Navigator.of(context).pop();
    }
  }
}
